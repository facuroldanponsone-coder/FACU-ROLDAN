import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  RefreshCw, 
  Star, 
  ArrowRight, 
  CheckCircle2, 
  XCircle, 
  Award, 
  Percent, 
  Volume2, 
  VolumeX, 
  MapPin, 
  Heart,
  Undo2,
  Coins
} from 'lucide-react';
import { questionPool } from './questionsData';
import { Question, ScreenState } from './types';

// Web Audio API Sound Effects Synthesizer
class SoundEffects {
  private ctx: AudioContext | null = null;
  public isMuted: boolean = false;

  constructor() {
    // Lazy loaded / initialized on user interaction to avoid browser autoplay blocks
  }

  private init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
  }

  playPop() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(350, t);
      osc.frequency.exponentialRampToValueAtTime(150, t + 0.1);
      gain.gain.setValueAtTime(0.08, t);
      gain.gain.linearRampToValueAtTime(0, t + 0.1);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(t + 0.1);
    } catch (_) {}
  }

  playCorrect() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, t); // C5
      osc.frequency.setValueAtTime(659.25, t + 0.08); // E5
      osc.frequency.setValueAtTime(783.99, t + 0.16); // G5
      osc.frequency.setValueAtTime(1046.50, t + 0.24); // C6
      gain.gain.setValueAtTime(0.12, t);
      gain.gain.linearRampToValueAtTime(0, t + 0.35);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(t + 0.35);
    } catch (_) {}
  }

  playIncorrect() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, t);
      osc.frequency.linearRampToValueAtTime(80, t + 0.35);
      gain.gain.setValueAtTime(0.15, t);
      gain.gain.linearRampToValueAtTime(0, t + 0.35);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(t + 0.35);
    } catch (_) {}
  }

  playTrophy() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const notes = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t + idx * 0.07);
        gain.gain.setValueAtTime(0.08, t + idx * 0.07);
        gain.gain.linearRampToValueAtTime(0, t + idx * 0.07 + 0.25);
        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        osc.start(t + idx * 0.07);
        osc.stop(t + idx * 0.07 + 0.25);
      });
    } catch (_) {}
  }
}

const countryFlags: Record<string, string> = {
  "Noruega": "🇳🇴",
  "Suiza": "🇨🇭",
  "Italia": "🇮🇹",
  "Venezuela": "🇻🇪",
  "Dinamarca": "🇩🇰",
  "Japón": "🇯🇵",
  "Singapur": "🇸🇬",
  "EE.UU.": "🇺🇸",
  "Australia": "🇦🇺",
  "Países Bajos": "🇳🇱",
  "Londres": "🇬🇧",
  "México": "🇲🇽"
};

export default function App() {
  const [screen, setScreen] = useState<ScreenState>('home');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [canAnswer, setCanAnswer] = useState<boolean>(true);
  
  // Game stats
  const [score, setScore] = useState<number>(0);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [incorrectCount, setIncorrectCount] = useState<number>(0);

  // Sound configurations
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const soundsRef = useRef<SoundEffects | null>(null);

  // Local Storage Records
  const [highScore, setHighScore] = useState<number>(0);
  const [gamesPlayed, setGamesPlayed] = useState<number>(0);

  // Init Sound Effector & Load Stats
  useEffect(() => {
    soundsRef.current = new SoundEffects();
    
    // Load highscore and state
    const savedHighScore = localStorage.getItem('cuantocuesta_highscore');
    if (savedHighScore) {
      setHighScore(parseInt(savedHighScore, 10));
    }
    const savedGamesPlayed = localStorage.getItem('cuantocuesta_played');
    if (savedGamesPlayed) {
      setGamesPlayed(parseInt(savedGamesPlayed, 10));
    }

    // Attempt to load mute state
    const savedMute = localStorage.getItem('cuantocuesta_muted');
    if (savedMute) {
      const val = savedMute === 'true';
      setIsMuted(val);
      if (soundsRef.current) {
        soundsRef.current.isMuted = val;
      }
    }
  }, []);

  const toggleMute = () => {
    const newVal = !isMuted;
    setIsMuted(newVal);
    localStorage.setItem('cuantocuesta_muted', String(newVal));
    if (soundsRef.current) {
      soundsRef.current.isMuted = newVal;
    }
  };

  const startQuiz = () => {
    if (soundsRef.current) soundsRef.current.playPop();

    // Select 8 random distinct questions from the pool
    const shuffled = [...questionPool].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, 8);

    setQuestions(selected);
    setCurrentIdx(0);
    setSelectedIdx(null);
    setCanAnswer(true);
    setScore(0);
    setCorrectCount(0);
    setIncorrectCount(0);
    setScreen('game');
  };

  const handleOptionClick = (idx: number) => {
    if (!canAnswer) return;
    setCanAnswer(false);
    setSelectedIdx(idx);

    const question = questions[currentIdx];
    const isCorrect = idx === question.correct;

    if (isCorrect) {
      setScore(prev => prev + 100);
      setCorrectCount(prev => prev + 1);
      if (soundsRef.current) soundsRef.current.playCorrect();
    } else {
      setIncorrectCount(prev => prev + 1);
      if (soundsRef.current) soundsRef.current.playIncorrect();
    }
  };

  const advanceQuestion = () => {
    if (soundsRef.current) soundsRef.current.playPop();

    if (currentIdx + 1 < 8) {
      setCurrentIdx(prev => prev + 1);
      setSelectedIdx(null);
      setCanAnswer(true);
    } else {
      // Calculate outcomes
      const finalAccuracy = Math.round((correctCount / 8) * 100);
      
      // Update high score in state & persistent storage
      if (score > highScore) {
        setHighScore(score);
        localStorage.setItem('cuantocuesta_highscore', String(score));
      }

      // Update games played count
      const updatedGames = gamesPlayed + 1;
      setGamesPlayed(updatedGames);
      localStorage.setItem('cuantocuesta_played', String(updatedGames));

      // Play success melody
      if (soundsRef.current) {
        soundsRef.current.playTrophy();
      }

      setScreen('results');
    }
  };

  const resetToHome = () => {
    if (soundsRef.current) soundsRef.current.playPop();
    setScreen('home');
  };

  // Percent progress helper
  const progressRatio = ((currentIdx) / 8) * 100;
  const currentQuestion: Question | undefined = questions[currentIdx];

  const getTrophyInfo = () => {
    const accuracy = Math.round((correctCount / 8) * 100);
    if (accuracy === 100) return { emoji: "👑", title: "¡Perfección Absoluta!", desc: "Tenés un radar global de precios impecable. ¡No te estafan en ningún rincón del planeta!" };
    if (accuracy >= 75) return { emoji: "🏆", title: "¡Excelente Nivel!", desc: "Tenés nociones sumamente claras del costo de vida global comparado con el nuestro." };
    if (accuracy >= 50) return { emoji: "🥈", title: "¡Bien Jugado!", desc: "Vas por buen camino, aunque a veces te sorprenda lo diferente que es el valor fuera del país." };
    return { emoji: "😅", title: "¡Un poco de despiste!", desc: "La inflación y los tipos de cambio nos confunden a todos. ¡Hora de repasar y jugar de nuevo!" };
  };

  const trophyInfo = getTrophyInfo();

  return (
    <div className="min-h-screen bg-art-bg text-art-dark flex flex-col justify-between font-sans selection:bg-art-accent/20 transition-colors">
      
      {/* Editorial Header Section */}
      <header className="h-20 border-b border-art-dark flex items-center justify-between px-4 sm:px-8 md:px-12 bg-art-bg select-none">
        <div className="flex items-center gap-4">
          <span className="text-xs font-bold tracking-widest uppercase py-1 px-2.5 bg-art-dark text-white select-none">
            {screen === 'game' ? `Nivel 0${currentIdx + 1}/08` : screen === 'results' ? 'Fin' : 'Inicio'}
          </span>
          <h1 className="font-serif italic text-xl sm:text-2xl tracking-tight font-bold cursor-pointer" onClick={resetToHome}>
            ¿Cuánto cuesta?
          </h1>
        </div>

        <div className="flex items-center gap-4 sm:gap-8">
          <div className="flex gap-6 sm:gap-10 text-xs font-bold tracking-tight uppercase">
            <div className="flex flex-col items-end">
              <span className="opacity-40 text-[10px]">Puntaje</span>
              <span className="text-base sm:text-lg font-mono font-bold">{score} pts</span>
            </div>
            <div className="flex flex-col items-end">
              <span className="opacity-40 text-[10px]">Acierto</span>
              <span className="text-base sm:text-lg font-mono font-bold">
                {currentIdx > 0 ? `${Math.round((correctCount / currentIdx) * 100)}%` : '100%'}
              </span>
            </div>
          </div>

          {/* Sound toggle button */}
          <button
            onClick={toggleMute}
            className="p-1.5 rounded-full border border-art-dark/40 hover:bg-art-accent hover:text-white transition-colors cursor-pointer"
            title={isMuted ? "Activar Sonido" : "Silenciar"}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Content Layout Container */}
      <main className="flex-1 w-full max-w-6xl mx-auto flex flex-col justify-center p-4 sm:p-8 md:p-12 overflow-hidden">
        <AnimatePresence mode="wait">
          
          {/* SCREEN: HOME */}
          {screen === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full max-w-3xl mx-auto bg-white border-2 border-art-dark rounded-[24px] overflow-hidden shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] p-6 sm:p-10 flex flex-col md:flex-row gap-8 items-center"
              id="home-screen"
            >
              <div className="flex-1 text-center md:text-left">
                <div className="inline-block px-3 py-1 bg-[#1A1A1A] text-white text-[10px] uppercase tracking-widest font-bold mb-4">
                  Quiz de Precios mundiales
                </div>
                
                <h2 className="text-5xl sm:text-6xl font-serif font-black tracking-tighter leading-none text-art-dark mb-4">
                  ¿Cuánto <br className="hidden sm:inline" /><span className="italic text-art-accent">cuesta?</span>
                </h2>

                <p className="text-slate-600 text-sm sm:text-base leading-relaxed mb-6">
                  ¿Sabés cuánto valen las cosas cotidianas fuera de Argentina? Poné a prueba tus nociones del costo de vida global y descubrí curiosidades sobre la economía de otros rincones del planeta.
                </p>

                {/* Local Stats Box */}
                <div className="grid grid-cols-2 gap-4 max-w-sm mb-6">
                  <div className="border border-art-dark p-3 bg-art-bg/30 rounded-lg">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Mejor marca</span>
                    <strong className="text-lg font-bold text-art-dark">{highScore} pts</strong>
                  </div>
                  <div className="border border-art-dark p-3 bg-art-bg/30 rounded-lg">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Partidas</span>
                    <strong className="text-lg font-bold text-art-dark">{gamesPlayed} completadas</strong>
                  </div>
                </div>

                <button
                  onClick={startQuiz}
                  className="w-full sm:w-auto bg-art-accent hover:bg-art-dark text-white border-2 border-art-dark font-sans font-black text-lg py-4 px-8 mt-2 transition-all duration-150 cursor-pointer flex items-center justify-center gap-3 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:shadow-none hover:translate-x-1 hover:translate-y-1"
                  id="btn-start-game"
                >
                  ¡EMPEZAR DESAFÍO!
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>

              {/* Decorative Visual Card */}
              <div className="w-full md:w-5/12 bg-art-gray border-2 border-art-dark p-8 rounded-[16px] flex flex-col items-center justify-center relative min-h-[250px] overflow-hidden">
                <div className="text-[100px] leading-none mb-4 select-none animate-bounce" style={{ animationDuration: '4s' }}>
                  🌎
                </div>
                <div className="absolute -top-6 -right-6 text-6xl opacity-20">💸</div>
                <div className="absolute -bottom-6 -left-6 text-6xl opacity-20">🍞</div>
                
                <span className="text-xs uppercase font-bold tracking-widest text-[#1a1a1a]/60 bg-white/85 px-3 py-1 border border-art-dark rounded-full">
                  12 países cargados
                </span>
                
                <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500 font-mono">
                  <span>Con amor desde Argentina</span>
                  <Heart className="w-3.5 h-3.5 text-art-accent fill-art-accent animate-pulse" />
                </div>
              </div>
            </motion.div>
          )}

          {/* SCREEN: GAME */}
          {screen === 'game' && currentQuestion && (
            <motion.div
              key="game"
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.99 }}
              className="bg-white border-2 border-art-dark rounded-[24px] overflow-hidden shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] flex flex-col md:flex-row min-h-[500px]"
              id="game-screen"
            >
              {/* Left Column: The Subject / Product Details */}
              <section className="w-full md:w-5/12 border-b md:border-b-0 md:border-r border-art-dark p-6 sm:p-10 flex flex-col justify-between bg-art-bg/30">
                <div>
                  <div className="text-[120px] leading-none mb-6 text-center md:text-left select-none drop-shadow-sm filter">
                    {currentQuestion.emoji}
                  </div>
                  
                  {/* Styled Header following Artistic Flair spec */}
                  <h2 className="text-5xl sm:text-6xl font-serif font-serif leading-[0.95] tracking-tighter mb-6 text-art-dark text-center md:text-left">
                    {(() => {
                      const words = currentQuestion.product.split(' ');
                      if (words.length > 1) {
                        return (
                          <>
                            {words[0]} <br />
                            <span className="italic text-art-accent">{words.slice(1).join(' ')}</span>
                          </>
                        );
                      }
                      return <span className="italic">{currentQuestion.product}</span>;
                    })()}
                  </h2>

                  {/* Location Info with interactive Country focus and flag */}
                  <div className="flex flex-col gap-2 mb-6">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-widest block text-center md:text-left">
                      Ubicación del Producto
                    </span>
                    <div className="flex items-center gap-3 justify-center md:justify-start">
                      <span className="text-3xl select-none leading-none">
                        {countryFlags[currentQuestion.country] || "🌐"}
                      </span>
                      <span className="text-xl font-bold tracking-tight text-art-dark">
                        {currentQuestion.country}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Argentina Baseline Reference Box */}
                <div className="p-5 bg-art-dark text-white rounded-tr-[50px] rounded-tl-[10px] rounded-br-[10px] rounded-bl-[10px] shadow-sm">
                  <span className="text-[9px] uppercase tracking-widest opacity-60 mb-1.5 block">
                    Referencia Local
                  </span>
                  <p className="text-base sm:text-lg font-serif italic text-amber-150">
                    En Argentina: {currentQuestion.argPrice}
                  </p>
                </div>
              </section>

              {/* Right Column: Interactive Option Selector Menu */}
              <section className="w-full md:w-7/12 p-6 sm:p-10 flex flex-col justify-between">
                <div>
                  <div className="mb-6">
                    <p className="text-xs uppercase font-mono font-bold tracking-widest text-[#1a1a1a]/40 mb-1.5">
                      Desafío Global
                    </p>
                    <h3 className="text-xl sm:text-2xl font-bold leading-snug tracking-tight text-art-dark">
                      ¿Cuál es el costo estimado de este producto/servicio en {currentQuestion.country}?
                    </h3>
                  </div>

                  {/* Interactive Button Grid Pattern */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6" id="options-grid">
                    {currentQuestion.options.map((optionText, index) => {
                      const isSelected = selectedIdx === index;
                      const isCorrectChoice = currentQuestion.correct === index;
                      const hasFeedback = selectedIdx !== null;

                      let btnClasses = "border-2 border-art-dark p-6 flex flex-col justify-between hover:bg-art-accent hover:text-white transition-all cursor-pointer text-left h-36";

                      if (hasFeedback) {
                        if (isCorrectChoice) {
                          btnClasses = "border-2 border-art-dark p-6 flex flex-col justify-between bg-emerald-500 text-white font-bold h-36 scale-[1.02] transition-transform";
                        } else if (isSelected) {
                          btnClasses = "border-2 border-art-dark p-6 flex flex-col justify-between bg-red-500 text-white font-bold h-36";
                        } else {
                          btnClasses = "border-2 border-art-dark p-6 flex flex-col justify-between bg-white text-slate-300 opacity-55 h-36 cursor-not-allowed";
                        }
                      } else {
                        // Unclicked grid boxes alternation style matching design spec
                        if (index === 1) {
                          btnClasses = "border-2 border-art-dark p-6 flex flex-col justify-between bg-art-dark text-white hover:bg-art-accent hover:-translate-y-1 transition-all cursor-pointer h-36 shadow-[3px_3px_0px_0px_rgba(255,92,0,1)]";
                        } else {
                          btnClasses = "border-2 border-art-dark p-6 flex flex-col justify-between bg-white hover:bg-art-accent hover:text-white hover:-translate-y-1 transition-all cursor-pointer h-36 shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]";
                        }
                      }

                      return (
                        <button
                          key={index}
                          disabled={hasFeedback}
                          onClick={() => handleOptionClick(index)}
                          className={btnClasses}
                        >
                          <span className={`text-[10px] font-mono font-bold tracking-wider uppercase ${
                            hasFeedback && (isCorrectChoice || isSelected) ? 'text-white' : 'opacity-60'
                          }`}>
                            Opción 0{index + 1}
                          </span>
                          <div className="flex items-baseline gap-1 mt-auto">
                            <span className="text-4xl font-sans font-black tracking-tighter">
                              {optionText}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Educational feedback panel when choice select triggers */}
                <AnimatePresence>
                  {selectedIdx !== null && (
                    <motion.div
                      key="fact-box-container"
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-2 border-art-dark bg-[#EBE8E2] p-5 relative overflow-hidden"
                      id="feedback-area"
                    >
                      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            {selectedIdx === currentQuestion.correct ? (
                              <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold uppercase tracking-wider rounded">
                                ¡Acierto! 🎉
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider rounded">
                                ¡Ups! 😅
                              </span>
                            )}
                            <span className="text-xs font-bold text-art-dark uppercase font-mono">
                              Respuesta real: {currentQuestion.options[currentQuestion.correct]}
                            </span>
                          </div>
                          
                          <p className="text-slate-700 text-xs sm:text-xs leading-relaxed font-mono" id="fact-box">
                            <span className="font-bold uppercase text-art-dark text-[10px] mr-1">Dato Global:</span>
                            {currentQuestion.fact}
                          </p>
                        </div>

                        <button
                          onClick={advanceQuestion}
                          className="w-full sm:w-auto self-stretch sm:self-center bg-art-accent text-white hover:bg-black font-sans font-black py-2 px-5 border border-art-dark shadow-[2px_2px_0px_0px_rgba(26,26,26,1)] hover:shadow-none hover:translate-x-0.5 cursor-pointer flex items-center justify-center gap-2 text-xs"
                        >
                          Siguiente
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </section>
            </motion.div>
          )}

          {/* SCREEN: RESULTS */}
          {screen === 'results' && (
            <motion.div
              key="results"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-3xl mx-auto bg-white border-2 border-art-dark rounded-[24px] overflow-hidden shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] p-6 sm:p-10 text-center"
              id="results-screen"
            >
              <span className="text-7xl block mb-2 animate-pulse" id="trophy-icon">
                {trophyInfo.emoji}
              </span>
              
              <h2 className="font-serif italic text-4xl sm:text-5xl font-black text-art-dark tracking-tight leading-tight mt-1" id="result-title">
                {trophyInfo.title}
              </h2>
              
              <p className="text-slate-600 text-sm max-w-md mx-auto mt-2 leading-relaxed">
                {trophyInfo.desc}
              </p>

              {/* Bento styled Stats Grid with hard borders */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-8 text-left">
                <div className="bg-art-bg/30 border-2 border-art-dark p-4 rounded-xl flex flex-col justify-between">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">Puntos</span>
                  <div className="mt-2 text-2xl font-black font-serif text-art-dark" id="final-score">
                    {score}
                  </div>
                </div>

                <div className="bg-art-bg/30 border-2 border-art-dark p-4 rounded-xl flex flex-col justify-between">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">Aciertos</span>
                  <div className="mt-2 text-2xl font-black font-serif text-art-dark" id="final-accuracy">
                    {Math.round((correctCount / 8) * 100)}%
                  </div>
                </div>

                <div className="bg-emerald-50 border-2 border-art-dark p-4 rounded-xl flex flex-col justify-between">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-emerald-600/80 block">Correctas</span>
                  <div className="mt-2 text-2xl font-black font-serif text-emerald-700" id="final-correct">
                    {correctCount}
                  </div>
                </div>

                <div className="bg-red-50 border-2 border-art-dark p-4 rounded-xl flex flex-col justify-between">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-red-600/80 block">Incorrectas</span>
                  <div className="mt-2 text-2xl font-black font-serif text-red-700" id="final-incorrect">
                    {incorrectCount}
                  </div>
                </div>
              </div>

              {/* New Record Spotlight Banner */}
              {score >= highScore && score > 0 && (
                <div className="mb-6 inline-flex items-center gap-2 bg-art-accent text-white border-2 border-art-dark px-5 py-2.5 font-mono text-xs font-bold shadow-[2px_2px_0px_0px_rgba(26,26,26,1)]">
                  <Star className="w-4 h-4 fill-white" />
                  <span>¡NUEVO RÉCORD PERSONAL ALCANZADO CON {highScore} PTS!</span>
                </div>
              )}

              {/* Replay action buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <button
                  onClick={startQuiz}
                  className="w-full sm:w-auto bg-art-accent hover:bg-art-dark text-white font-sans font-black text-base py-4 px-8 border-2 border-art-dark flex items-center justify-center gap-2 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all cursor-pointer"
                >
                  <RefreshCw className="w-5 h-5" />
                  JUGAR DE NUEVO
                </button>

                <button
                  onClick={resetToHome}
                  className="w-full sm:w-auto bg-art-gray hover:bg-slate-200 text-art-dark font-sans font-black text-sm py-4 px-8 border-2 border-art-dark flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Undo2 className="w-4 h-4" />
                  Volver al Inicio
                </button>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Retro-styled Editorial Footer */}
      <footer className="h-16 border-t border-art-dark flex items-center justify-between px-4 sm:px-8 md:px-12 bg-art-gray text-[11px] font-mono text-art-dark uppercase tracking-widest select-none">
        <div className="flex items-center gap-3">
          <span className="opacity-50">Estilo:</span>
          <span className="font-serif italic font-bold">Artistic Flair Theme</span>
        </div>
        <div className="hidden sm:flex items-center gap-1">
          <span>Inspirado con</span>
          <Heart className="w-3 h-3 text-art-accent fill-art-accent" />
          <span>por mentes curiosas</span>
        </div>
      </footer>

    </div>
  );
}
