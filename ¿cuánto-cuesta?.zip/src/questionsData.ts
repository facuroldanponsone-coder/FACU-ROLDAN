import { Question } from './types';

export const questionPool: Question[] = [
  {
    product: "Leche (1L)",
    emoji: "🥛",
    country: "Noruega",
    argPrice: "$1.200 (USD 1.20)",
    options: ["USD 1.10", "USD 2.25", "USD 0.80", "USD 3.50"],
    correct: 1,
    fact: "Noruega tiene uno de los costos de vida más altos; los lácteos tienen altos impuestos para proteger al productor local al no pertenecer a la Unión Europea."
  },
  {
    product: "Pan de molde",
    emoji: "🍞",
    country: "Suiza",
    argPrice: "$2.500 (USD 2.50)",
    options: ["USD 1.50", "USD 2.20", "USD 3.80", "USD 6.00"],
    correct: 2,
    fact: "En Suiza, la comida es aproximadamente un 70% más cara que la media europea debido a altos salarios y aranceles de importación."
  },
  {
    product: "Café Espresso",
    emoji: "☕",
    country: "Italia",
    argPrice: "$2.000 (USD 2.00)",
    options: ["USD 1.30", "USD 4.50", "USD 3.00", "USD 0.50"],
    correct: 0,
    fact: "En Italia, el precio de un espresso tomado parado en la barra ('al banco') está regulado por costumbre social y suele ser sumamente accesible."
  },
  {
    product: "Nafta (1L)",
    emoji: "⛽",
    country: "Venezuela",
    argPrice: "$950 (USD 0.95)",
    options: ["USD 1.20", "USD 0.03", "USD 0.50", "USD 2.10"],
    correct: 1,
    fact: "Históricamente, Venezuela ha tenido la nafta más barata del mundo gracias a masivos subsidios estatales fijos."
  },
  {
    product: "Cerveza (Pinta)",
    emoji: "🍺",
    country: "Dinamarca",
    argPrice: "$3.500 (USD 3.50)",
    options: ["USD 2.00", "USD 4.00", "USD 7.50", "USD 12.00"],
    correct: 2,
    fact: "En Copenhague, una cerveza tirada en un pub promedio ronda los 7 u 8 dólares, influenciado por altos impuestos al alcohol."
  },
  {
    product: "Huevos (12u)",
    emoji: "🥚",
    country: "Japón",
    argPrice: "$2.200 (USD 2.20)",
    options: ["USD 1.50", "USD 2.60", "USD 5.00", "USD 0.90"],
    correct: 1,
    fact: "Japón consume muchísimos huevos frescos diariamente; su mercado interno está muy optimizado, manteniendo precios bastante competitivos."
  },
  {
    product: "Taxi (5km)",
    emoji: "🚕",
    country: "Singapur",
    argPrice: "$4.500 (USD 4.50)",
    options: ["USD 4.00", "USD 12.00", "USD 25.00", "USD 8.50"],
    correct: 3,
    fact: "En comparación con el altísimo costo de poseer un automóvil propio en Singapur, los taxis regulados son muy eficientes y no tan costosos."
  },
  {
    product: "Corte de pelo (Hombre)",
    emoji: "💇‍♂️",
    country: "EE.UU.",
    argPrice: "$8.000 (USD 8.00)",
    options: ["USD 10.00", "USD 15.00", "USD 35.00", "USD 60.00"],
    correct: 2,
    fact: "En la mayoría de las ciudades norteamericanas, un corte básico con propina incluida rara vez baja de los 30 o 35 dólares debido al costo de vida y servicio personal."
  },
  {
    product: "Pizza Margherita",
    emoji: "🍕",
    country: "Australia",
    argPrice: "$10.000 (USD 10.00)",
    options: ["USD 18.00", "USD 8.00", "USD 5.00", "USD 12.00"],
    correct: 0,
    fact: "Australia tiene uno de los salarios mínimos legales por hora más elevados del mundo, lo que repercute directamente en costos de hostelería."
  },
  {
    product: "Queso Gouda (1kg)",
    emoji: "🧀",
    country: "Países Bajos",
    argPrice: "$11.000 (USD 11.00)",
    options: ["USD 20.00", "USD 12.00", "USD 5.00", "USD 30.00"],
    correct: 1,
    fact: "Al ser uno de los mayores y más eficientes productores lácteos del continente, el queso gouda es muy accesible y de excelente calidad en origen."
  },
  {
    product: "Viaje en Subte",
    emoji: "🚇",
    country: "Londres",
    argPrice: "$750 (USD 0.75)",
    options: ["USD 1.50", "USD 4.20", "USD 0.90", "USD 2.50"],
    correct: 1,
    fact: "El histórico subterráneo de Londres (Underground o 'Tube') es uno de los transportes metropolitanos de pasajeros más caros del planeta."
  },
  {
    product: "Pimiento/Morrón (1kg)",
    emoji: "🫑",
    country: "México",
    argPrice: "$4.000 (USD 4.00)",
    options: ["USD 1.80", "USD 4.50", "USD 6.00", "USD 0.50"],
    correct: 0,
    fact: "México es un enorme productor de hortalizas y variedades de chile, lo que abarata drásticamente el costo de las verduras frescas locales."
  }
];
