export interface Question {
  product: string;
  emoji: string;
  country: string;
  argPrice: string;
  options: string[];
  correct: number;
  fact: string;
}

export type ScreenState = 'home' | 'game' | 'results';

export interface GameStats {
  score: number;
  correctCount: number;
  incorrectCount: number;
  accuracy: number;
}
